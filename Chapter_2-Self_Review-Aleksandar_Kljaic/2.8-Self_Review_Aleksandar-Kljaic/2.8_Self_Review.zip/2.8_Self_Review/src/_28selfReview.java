import java.util.Scanner; // program uses class Scanner

public class _28selfReview 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner input = new Scanner( System.in );
		
		int varB;
		int varC;
		int product;
		System.out.print( "Enter an integer: ");
		varB = input.nextInt();
		
		System.out.print( "Enter an integer: " );
		varC = input.nextInt();
		
		product = varB * varC;
		// a = b*c
		
		System.out.printf( "Product is %d\n", product); // Performs a sample payroll calculation.
	}

}
